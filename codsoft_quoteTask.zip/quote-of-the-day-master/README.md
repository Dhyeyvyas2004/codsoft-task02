#Quote of the Day

QotD is a simple application that lets you flip through random quotes from a quotes 'database' (its currently just a file with about 400+ quotes) that are displayed one at a time when you click the button on the application.

The application is available on the [Google Play Store](https://play.google.com/store/apps/details?id=com.seriousplay.qotd) and is ad absolutely ad-free.

This application is born out of an interest to teach myself Android programming and as a source of reference for my future projects. I hope it ends up being a useful reference.